package fr.perso.mesclasses;

public class Out {

	public static void p(String val) {
		System.out.println(val);
	}
	public static void p(int val) {
		System.out.println(val);
	}
	public static void p(Object Val) {
		System.out.println(Val);
	}
	public static void p() {
		System.out.println();
	}
	public static void etoiles() {
		System.out.println("********************************");
	}
}
